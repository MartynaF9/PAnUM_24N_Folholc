package com.example.lab04.model;

public class Cafe {
    private final String name, address, hours;

    public static final Cafe[] cafes = {
            new Cafe("Kafeteria – Częstochowa I", "ul. Długa 5, Częstochowa", "8:00–20:00"),
            new Cafe("Kafeteria – Częstochowa II", "ul. Krótka 10, Częstochowa", "9:00–18:00"),
            new Cafe("Kafeteria – Warszawa", "ul. Marszałkowska 1, Warszawa", "7:00–22:00")
    };

    private Cafe(String n, String a, String h) { name = n; address = a; hours = h; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getHours() { return hours; }

    @Override public String toString() { return name; }
}
